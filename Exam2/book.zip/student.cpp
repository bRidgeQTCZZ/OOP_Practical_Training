#include <iostream>
using namespace std;
#include "student.h"
#include "shelf.h"
#include "book.h"

Book* Student::takeBook(Shelf shelf, const char isbn[]) {
	shelf.bookBeTaken();
	Book* temp = new(Book);
	temp->setName(isbn);
	return temp;
}

void Student::backBook(Shelf shelf, Book book) {
	shelf.bookBeBack();
}